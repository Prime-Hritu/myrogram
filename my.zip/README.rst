myrogram
=====

• Telegram_
• Github_

install
=======

.. code:: python
    
    pip install https://github.com/Prime-Hritu/myrogram/

Usage
=====

``myrogram``